from webdriver_manager.chrome import ChromeDriverManager
from bs4 import BeautifulSoup
import requests
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
import time
import sys

# TODO: add check for edge cases (no post, no brand_hashtag)

from keras.models import load_model
from PIL import Image, ImageOps
import numpy as np

def get_inst_image(uniq, hashtag):

    chrome_options = Options()

    #chrome_options.add_argument("--no-sandbox") # linux only
    chrome_options.headless = True


    driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=chrome_options)
    driver.get(f"https://www.instagram.com/explore/tags/{uniq}/")

    time.sleep(3)

    soup = BeautifulSoup(driver.page_source, 'lxml')

    div = soup.find("div", {"class": "_aagv"})
    img = div.find("img")


    link = img["src"]
    text = img["alt"]

    found_tags = [tag.strip() for tag in text[text.find('#')+1:].split('#')]
    brand_tag_included = False

    for tag in found_tags:
        if tag == hashtag:
            brand_tag_included = True

    response = requests.get(link)
    file = open("input.jpg", "wb")
    file.write(response.content)
    file.close()
    
    return

htg = sys.argv[1]
cf_num = sys.argv[2]
brand_tag = sys.argv[3]
print(htg)
get_inst_image(htg, brand_tag)

print(brand_predictor('keras1_model.h5', cf_num))